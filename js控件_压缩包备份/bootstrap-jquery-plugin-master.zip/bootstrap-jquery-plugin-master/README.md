Bootstrap jQuery Plugin Library
----
Some jQuery plugins based on bootstrap, have fun.

Based on

    bootstrap:  3.x
    jquery:     1.x



Documents 
====
[bootstrap.ourjs.com](http://bootstrap.ourjs.com)

License
====
MIT, see our license file
